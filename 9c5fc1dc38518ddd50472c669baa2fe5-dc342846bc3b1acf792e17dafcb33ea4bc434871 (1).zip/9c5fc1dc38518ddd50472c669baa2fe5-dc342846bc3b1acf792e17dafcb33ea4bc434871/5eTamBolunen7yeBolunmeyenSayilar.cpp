//5 e tam bolunen  7 ye bolunmeyen sayilar
#include <iostream>
using namespace std ;
int main (){
	int i,toplam=0,sayac=0; 
	for (i=1;i<=1000;i++){
		if (i%5==0 && i%7!=0){
			sayac++;
			toplam+=i;
			cout << "hangi sayilar boyle ="<<i<<endl;
		}	
	}
	cout << "sayilarin toplami = "<<toplam << endl;
	cout << " kac adet sayi var = "<<sayac<<endl;	
	return 0;
}
